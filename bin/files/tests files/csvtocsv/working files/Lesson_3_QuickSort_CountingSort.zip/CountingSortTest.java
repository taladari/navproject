

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class CountingSortTest {

	@Test(timeout=5000)
	public void test1() {
		int size = 10000000;
		int [] a = MyLibrary.randomIntegerArray(size);
		int[]c = Arrays.copyOf(a, size);
		long  timeBefore,timeAfter;
		double elapse;
	// java sort
		timeBefore = System.currentTimeMillis();
		Arrays.sort(a);
		timeAfter = System.currentTimeMillis();
		elapse = (timeAfter-timeBefore)/1000.0;
		System.out.println("Java Sort time = " + elapse);
		assertTrue(MyLibrary.isSorted(a));
	// counting sort
		timeBefore = System.currentTimeMillis();
		CountingSort.countingSort(c);
		timeAfter = System.currentTimeMillis();
		elapse = (timeAfter-timeBefore)/1000.0;
		System.out.println("Counting Sort time = " + elapse);
		assertTrue(MyLibrary.isSorted(c));
	}
	@Test(timeout=500)
	public void test4() {
		int [] a = {877, 567, 3456, 876, 467, 26, 934, 9876, 1, 4567,90,100,0};
		CountingSort.countingSort(a);
		int[] expected = {0,1,26,90,100,467,567,876,877,934,3456,4567,9876};
		assertArrayEquals(expected, a);
	}
	@Test(timeout=500)
	public void test5() {
		int [] a = {0,1,26,90,100,467,567,876,877,934,3456,4567,9876};
		CountingSort.countingSort(a);
		int[] expected = {0,1,26,90,100,467,567,876,877,934,3456,4567,9876};
		assertArrayEquals(expected, a);
	}
	@Test(timeout=500)
	public void test6() {
		int [] a = {9876,4567,3456,934,877,876,567,467,100,90,26,1,0};
		CountingSort.countingSort(a);
		int[] expected = {0,1,26,90,100,467,567,876,877,934,3456,4567,9876};
		assertArrayEquals(expected, a);
	}
}
/*
	Java Sort time = 0.863
	Counting Sort time = 0.302
*/