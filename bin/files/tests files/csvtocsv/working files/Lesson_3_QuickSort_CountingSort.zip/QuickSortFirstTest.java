import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;


public class QuickSortFirstTest {
	@Test(timeout=5000)
	public void test1() {
		int[] a = {1,3,5,6,7,90};
		QuickSortFirst.quickSort(a);
		int[] expected = {1,3,5,6,7,90};
		assertArrayEquals(expected, a);
	}
	@Test(timeout=5000)
	public void test2() {
		int[] a = {45,34,15,7,5,3,0};
		int[] expected = {0,3,5,7,15,34,45};
		QuickSortFirst.quickSort(a);
		assertArrayEquals(expected, a);
	}
	@Test(timeout=5000)
	public void test3() {
		int[] a = {7,3,9,5,4,8,1,8};
		int[] expected = {1,3,4,5,7,8,8,9};
		QuickSortFirst.quickSort(a);
		assertArrayEquals(expected, a);
	}
	@Test(timeout=5000)
	public void test4() {
		int size = 1000;
		int[] a = MyLibrary.randomIntegerArray(size);
		long  timeBefore = System.currentTimeMillis();
		QuickSortFirst.quickSort(a);
		long timeAfter = System.currentTimeMillis();
		double elapse = (timeAfter-timeBefore)/1000.0;;
		System.out.println("size = "+size+",  QuickSort time = " +  + elapse+" seconds");	
		assertTrue(MyLibrary.isSorted(a));
	}
	@Test(timeout=5000)
	public void test5() {
		int size = 10000000;
		int[] a = MyLibrary.randomIntegerArray(size);
		int[]b = Arrays.copyOf(a, a.length);
		int[]c = Arrays.copyOf(a, a.length);
		//Quick Sort
		long  timeBefore = System.currentTimeMillis();
		QuickSortFirst.quickSort(a);
		long timeAfter = System.currentTimeMillis();
		double elapse = (timeAfter-timeBefore)/1000.0;;
		System.out.println("size = "+size+",  QuickSort time = " +  + elapse+" seconds");	
		assertTrue(MyLibrary.isSorted(a));
		//Java Sort
		timeBefore = System.currentTimeMillis();
		Arrays.sort(b);
		timeAfter = System.currentTimeMillis();
		elapse = (timeAfter-timeBefore)/1000.0;;
		System.out.println("size = "+size+",  JavaSort time = " +  + elapse+" seconds");	
		assertTrue(MyLibrary.isSorted(a));
		//Merge Sort
		timeBefore = System.currentTimeMillis();
		MergeSortFirst.mergeSort(c);
		timeAfter = System.currentTimeMillis();
		elapse = (timeAfter-timeBefore)/1000.0;;
		System.out.println("size = "+size+",  MergeSort time = " +  + elapse+" seconds");	
		assertTrue(MyLibrary.isSorted(c));
		//Quick Sort  of sorted array
		timeBefore = System.currentTimeMillis();
		QuickSortFirst.quickSort(a);
		timeAfter = System.currentTimeMillis();
		elapse = (timeAfter-timeBefore)/1000.0;;
		System.out.println("size = "+size+",  QuickSort time = " +  + elapse+" seconds");	
		assertTrue(MyLibrary.isSorted(a));
	}
}
/*
	QuickSort time = 0.0 seconds
	QuickSort time = 1.139 seconds
	JavaSort time = 0.844 seconds
	MergeSort time = 1.846 seconds
	Java Sort time = 0.863
	Counting Sort time = 0.302

*/